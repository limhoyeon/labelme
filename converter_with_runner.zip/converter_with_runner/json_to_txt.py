from glob import glob
import json
import os
OUTPUT_DIR = "json_to_txt"
WIDTH = 640
HEIGHT = 480
IMGFORMAT = ".png"


if os.path.exists(os.path.join(os.getcwd(), OUTPUT_DIR)):
    raise Exception("result dir exists")
else:
    os.mkdir(os.path.join(os.getcwd(), OUTPUT_DIR))
    os.mkdir(os.path.join(os.getcwd(), OUTPUT_DIR, "dot"))
    os.mkdir(os.path.join(os.getcwd(), OUTPUT_DIR, "cls"))
    


for anno_name in glob('*.json'):
    dot_path = os.path.join(os.getcwd(),OUTPUT_DIR,"dot",anno_name.replace(".json", ".txt"))
    cls_path = os.path.join(os.getcwd(),OUTPUT_DIR,"cls",anno_name.replace(".json", ".txt"))
    
    with open(anno_name) as f:
        json_dict = json.load(f)
        
    labels_arr = []
    point_arr = []
    for item in json_dict["shapes"]:
        label = item["label"]
        point = str(int(item["points"][0][0]))+" "+str(int(item["points"][0][1]))
        labels_arr.append(label)
        point_arr.append(point)
    
    with open(dot_path, "w") as txt_file:
        for line in point_arr:
            txt_file.write(line + "\n")

    with open(cls_path, "w") as txt_file:
        for line in labels_arr:
            txt_file.write(line + "\n")