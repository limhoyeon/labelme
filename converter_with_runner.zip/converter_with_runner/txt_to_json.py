from glob import glob
import json
import os
OUTPUT_DIR = "txt_to_json"
WIDTH = 640
HEIGHT = 480
IMGFORMAT = ".png"


if os.path.exists(os.path.join(os.getcwd(), OUTPUT_DIR)):
    raise Exception("result dir exists")
else:
    os.mkdir(os.path.join(os.getcwd(), OUTPUT_DIR))

for anno_name in glob('*.txt'):
    json_path = os.path.join(os.getcwd(),OUTPUT_DIR,anno_name.replace(".txt", ".json"))
    img_name = anno_name.replace(".txt", IMGFORMAT)
    
    f = open(os.path.join(os.getcwd(), anno_name), 'r')
    
    shape_arr = []
    lines = f.readlines()
    for line in lines:
        point = list(map(float, line.split(" ")))
        
        shape_dict = {
            "label": "-1",
            "points": [point],
            "group_id": None,
            "shape_type": "point",
            "flags": {}
        }
        shape_arr.append(shape_dict)
    f.close()
    
    result_dict = {
        "version": "4.5.9",
        "flags": {},
        "shapes": shape_arr,
        "imagePath": img_name,
        "imageData": None,
        "imageHeight": HEIGHT,
        "imageWidth": WIDTH
    }
    with open(json_path, 'w') as f:
        json.dump(result_dict, f, indent=4)